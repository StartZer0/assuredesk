"""AssureDesk application."""
