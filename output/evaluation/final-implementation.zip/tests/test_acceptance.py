"""Regression tests for the unfinished acceptance requirements."""

import math
import pytest
from sqlalchemy import select
from app import policy, service
from app.db import Attempt, Draft, Event, Question, QuestionVersion, Source, User, Workbook
from app.operations import delete_source, retention, status
from app.scoring import ranking, bundle_coverage, summarize
from app.schema import Support
from app.workflow import Engine
from conftest import Embeddings, Generator
from test_boundaries import start, propose, user
from test_api import client


def test_ranking_known_order_duplicates_and_empty_gold():
    m = ranking(["noise", "a", "a", "b"], {"a", "b"}, 4)
    assert m["recall"]["value"] == 1 and m["precision"]["value"] == 0.5
    assert m["mrr"] == 0.5
    assert m["ndcg"] == pytest.approx((1 / math.log2(3) + 1 / math.log2(5)) / (1 + 1 / math.log2(3)))
    assert ranking([], set(), 3)["recall"]["value"] is None
    assert ranking(["a"], {"a", "b"}, 3)["precision"]["value"] == 1 / 3


def test_bundle_requires_complete_spans_and_all_sources():
    case = {
        "requirements": [
            {
                "bundles": [
                    [
                        {"source": "s", "hash": "h", "start": 0, "end": 10},
                        {"source": "t", "hash": "i", "start": 0, "end": 4},
                    ]
                ]
            }
        ]
    }
    spans = {
        "a": {"source": "s", "hash": "h", "start": 0, "end": 6},
        "b": {"source": "s", "hash": "h", "start": 6, "end": 10},
        "c": {"source": "t", "hash": "i", "start": 0, "end": 4},
    }
    assert bundle_coverage(case, ["a", "c"], spans)["numerator"] == 0
    assert bundle_coverage(case, ["a", "b", "c"], spans)["numerator"] == 1
    spans["c"]["hash"] = "stale"
    assert bundle_coverage(case, list(spans), spans)["numerator"] == 0


def test_missing_runs_do_not_improve_complete_score():
    cases = [
        {"id": str(i), "family": str(i), "disposition": "ANSWERABLE", "requirements": []} for i in range(2)
    ]
    runs = [{"case": "0", "variant": "corrective", "run": "r", "draft": {"answer": "Yes", "evidence": []}}]
    report = summarize(cases, runs, [{"run": "r", "adjudicated": True, "complete_supported": True}], {})
    assert report["variants"]["corrective"]["supported_complete"]["value"] == 0.5
    assert report["variants"]["corrective"]["missing_runs"] == ["1"]
    assert report["status"] == "incomplete" and not report["semantic_gate"]["passed"]


def test_immutable_intermediate_question_revisions(env):
    c = client(env)
    for revision, value in [(1, "Changed once"), (2, "Changed twice")]:
        assert (
            c.patch(f"/v1/questions/{env.q}", json={"expected_revision": revision, "text": value}).status_code
            == 200
        )
    h = c.get(f"/v1/questions/{env.q}/history").json()
    assert [x["text"] for x in h["questions"]][-2:] == ["Changed once", "Changed twice"]
    with env.db.transaction() as s:
        assert len(list(s.scalars(select(QuestionVersion).where(QuestionVersion.question_id == env.q)))) == 3


def test_claim_mapping_binds_approval_and_requires_checks(env):
    with env.db.transaction() as s:
        u = user(s, env, "reviewer")
        d = service.new_draft(s, u, env.q, 1, "Yes", "TLS 1.3", [env.chunks["public"]])
        with pytest.raises(policy.Rejected, match="claim_review_required"):
            service.approve(s, u, env.q, d.revision, True, claim_reviews=[False])
        approval = service.approve(
            s,
            u,
            env.q,
            d.revision,
            True,
            claim_reviews=[True],
            reason="Public TLS statement supports this claim",
        )
        d.claims = [{"text": "Unreviewed extra claim", "evidence_ids": d.evidence}]
        q, b = service.question_context(s, u, env.q)
        assert service.fingerprint(s, u, q, b, d) != approval.fingerprint
        assert approval.support_review["revision"] == d.revision


def test_checkpoint_loss_after_artifact_does_not_duplicate_stage(env):
    ident = start(env)
    gen = Generator([propose, Support(supported=True, missing=[], next_queries=[])])
    engine = Engine(env.db, gen, Embeddings())
    state = {"run_id": ident, "step": 0}
    state.update(engine.bounded(engine.search)(state))
    state.update(engine.bounded(engine.assess)(state))
    output = engine.bounded(engine.check)(state)
    with env.db.transaction() as s:
        draft_id = s.get(Question, env.q).current_draft
        attempts = len(list(s.scalars(select(Attempt))))
    reconstructed = Engine(env.db, Generator([]), Embeddings())
    assert reconstructed.bounded(reconstructed.check)(state) == output
    with env.db.transaction() as s:
        assert s.get(Question, env.q).current_draft == draft_id
        assert len(list(s.scalars(select(Draft)))) == 1
        assert len(list(s.scalars(select(Attempt)))) == attempts


def test_replay_rechecks_permissions(env):
    ident = start(env)
    engine = Engine(env.db, Generator([]), Embeddings())
    state = {"run_id": ident, "step": 0}
    engine.bounded(engine.search)(state)
    with env.db.transaction() as s:
        s.get(User, env.sales).active = False
    with pytest.raises(policy.Rejected):
        engine.bounded(engine.search)(state)


def test_restricted_search_does_not_cross_customer(env):
    rows = client(env, "reviewer").get(f"/v1/search?workbook_id={env.book}&query=CANARY").json()
    assert env.chunks["internal"] in {r["id"] for r in rows}
    assert env.chunks["nova"] not in {r["id"] for r in rows}
    assert client(env).get(f"/v1/search?workbook_id={env.book}&query=CANARY").status_code == 404


def test_deletion_purges_derived_records_and_keeps_tombstone(env):
    with env.db.transaction() as s:
        service.new_draft(s, user(s, env), env.q, 1, "Yes", "TLS 1.3", [env.chunks["public"]])
        original = s.get(Source, env.sources["public"]).object_hash
    result = delete_source(env.db, env.objects, env.sources["public"], env.reviewer)
    assert result["removed_workbooks"] == 1
    with env.db.transaction() as s:
        assert s.get(Source, env.sources["public"]) is None and s.get(Workbook, env.book) is None
        assert not list(s.scalars(select(Draft)))
        assert s.scalar(select(Event).where(Event.action == "source_deleted")).details["tombstone"]
    assert not (env.objects.root / original).exists()


def test_retention_preview_then_purge(env):
    with env.db.transaction() as s:
        s.get(Workbook, env.book).created = 1
    assert env.book in retention(env.db, env.objects)["expired_workbooks"]
    with env.db.transaction() as s:
        assert s.get(Workbook, env.book)
    retention(env.db, env.objects, apply=True)
    with env.db.transaction() as s:
        assert s.get(Workbook, env.book) is None


def test_ops_alerts_for_missing_worker(env):
    assert "worker_heartbeat_missing" in status(env.db, env.objects)["alerts"]


def correction_scenario(env):
    from app.db import Chunk
    from app.schema import Proposal

    with env.db.transaction() as s:
        reviewer = user(s, env, "reviewer")
        for i in range(18):
            value = f"Customer hosting region EU policy {i}"
            if i == 17:
                value = "Recovery archive retention is thirty days."
            src = service.add_source(
                s,
                reviewer,
                env.objects,
                value.encode(),
                [{"text": value, "locator": "section:1"}],
                dict(
                    family=f"recovery-{i}",
                    title=f"Recovery {i}",
                    account="*",
                    roles=["sales", "security_reviewer"],
                    disclosure="public",
                    audience=[],
                    valid_from="2026-01-01",
                    valid_until="2027-12-31",
                    authority="approved_policy",
                ),
            )
            c = s.scalar(select(Chunk).where(Chunk.source_id == src.id))
            c.embedding, c.embedding_model = ([-1.0] if i == 17 else [1.0]) + [0.0] * 383, "fake"
            service.activate_source(s, reviewer, src.id)
        s.get(Question, env.q).text = "Customer hosting region EU policy and archive window"

    def assess(payload):
        found = [e for e in payload["evidence"] if "thirty days" in e["text"]]
        hosting = [e for e in payload["evidence"] if "Customer hosting region EU policy" in e["text"]]
        if found and hosting:
            return Proposal(
                status="draft_proposed",
                requirements=[
                    {
                        "text": "Archive retention is thirty days.",
                        "coverage": "supported",
                        "evidence_ids": [found[0]["id"]],
                    },
                    {
                        "text": "Customer hosting region is EU.",
                        "coverage": "supported",
                        "evidence_ids": [hosting[0]["id"]],
                    },
                ],
                next_queries=[],
                answer="Yes",
                explanation="Customer hosting region is EU. Archive retention is thirty days.",
            )
        return Proposal(
            status="needs_evidence",
            requirements=[{"text": "retention", "coverage": "missing", "evidence_ids": []}],
            next_queries=["recovery archive retention thirty days"],
            answer=None,
            explanation="",
        )

    class QueryEmbeddings(Embeddings):
        def query(self, text):
            return ([-1.0] if "thirty" in text else [1.0]) + [0.0] * 383

    return Generator(
        [assess, assess, Support(supported=True, missing=[], next_queries=[])]
    ), QueryEmbeddings()


def test_correction_recovers_with_real_retrieval(env):
    from langgraph.checkpoint.memory import InMemorySaver
    from app.db import Run

    gen, embeddings = correction_scenario(env)
    ident = start(env)
    Engine(env.db, gen, embeddings).graph(InMemorySaver()).invoke(
        {"run_id": ident, "route": "search"}, {"configurable": {"thread_id": ident}}
    )
    with env.db.transaction() as s:
        run = s.get(Run, ident)
        assert run.rounds == 2 and run.record["trace"][1]["new_ids"]
        assert s.get(Draft, run.record["draft_id"]).supported


def test_pending_rebuild_cached_vectors_and_atomic_supersession(env):
    from app.db import Chunk
    from app.worker import index_pending
    from test_boundaries import approve_all

    class Indexer:
        model_id = "fake"
        revision = "test-artifact-v1"
        calls = 0

        def documents(self, texts):
            self.calls += len(texts)
            return [[1.0] + [0.0] * 383 for _ in texts]

    indexer = Indexer()
    approve_all(env)
    with env.db.transaction() as s:
        u = user(s, env, "reviewer")
        old = s.get(Source, env.sources["public"])
        chunk = s.scalar(select(Chunk).where(Chunk.source_id == old.id))
        metadata = {
            key: getattr(old, key)
            for key in (
                "family",
                "title",
                "account",
                "roles",
                "disclosure",
                "audience",
                "valid_from",
                "valid_until",
                "authority",
                "provenance",
            )
        }
        blocks = [{"text": chunk.text, "locator": chunk.locator}]
        content = env.objects.get(old.object_hash)
        rebuilt = service.add_source(s, u, env.objects, content, blocks, metadata, rebuild_of=old.id)
        rebuilt_id = rebuilt.id
        assert rebuilt.pipeline["rebuild_of"] == old.id
        assert (
            service.add_source(s, u, env.objects, content, blocks, metadata, rebuild_of=old.id).id
            == rebuilt_id
        )
        assert not rebuilt.active and not old.superseded
        service.export_manifest(s, u, s.get(Workbook, env.book))
        with pytest.raises(policy.Rejected, match="source_not_indexed"):
            service.activate_source(s, u, rebuilt_id, supersedes=old.id)
    index_pending(env.db, indexer)
    assert indexer.calls == 1
    with env.db.transaction() as s:
        u = user(s, env, "reviewer")
        service.activate_source(s, u, rebuilt_id, supersedes=env.sources["public"])
        assert s.get(Source, rebuilt_id).active and s.get(Source, env.sources["public"]).superseded
        with pytest.raises(policy.Rejected):
            service.export_manifest(s, u, s.get(Workbook, env.book))
        again = service.add_source(s, u, env.objects, content, blocks, metadata, rebuild_of=rebuilt_id)
        again_id = again.id
    index_pending(env.db, indexer)
    assert indexer.calls == 1
    with env.db.transaction() as s:
        assert s.scalar(select(Chunk).where(Chunk.source_id == again_id)).embedding_model == "fake"


def test_chunked_upload_limit_without_content_length(env):
    c = client(env)
    response = c.post("/v1/questionnaires/import", content=(b"x" * (6 * 1024**2) for _ in range(2)))
    assert response.status_code == 413


def test_evidence_picker_excludes_readable_internal_and_other_customer(env):
    c = client(env, "reviewer")
    options = c.get(f"/v1/questions/{env.q}/evidence-options").json()
    ids = {r["id"] for r in options}
    assert env.chunks["public"] in ids
    assert env.chunks["internal"] not in ids and env.chunks["nova"] not in ids
