# AssureDesk

AssureDesk helps a security reviewer answer a SaaS customer's questionnaire using permitted source documents, review exact claims and citations, and export only current approved revisions. The product and customers in this pilot are fictional.

**Status:** implemented and verified as a restricted local pilot. **99 tests passed**, including a real browser, PostgreSQL/pgvector, parser confinement and process-death recovery. Container workflow acceptance and encrypted fresh restoration passed. The completed 90-run locked comparison **failed the semantic quality gate**; independent validation and a configured scheduled off-host backup remain outstanding. These limitations prevent a production-readiness claim.

## Run locally

Python 3.12 and PostgreSQL 17 with pgvector are required. The application is one FastAPI process, one worker, and PostgreSQL; there is no broker, separate vector service, or multi-agent runtime.

```sh
uv sync --frozen
cp .env.example .env  # only for a NEW installation; never overwrite existing credentials
uv run alembic upgrade head
uv run python -m app.cli checkpoints
uv run python -m app.cli prepare-model
uv run python -m app.cli seed
uv run python -m app.cli check-parser
uv run uvicorn app.web:create_app --factory --host 127.0.0.1 --port 8012 --no-access-log
# Second terminal, same directory:
uv run python -m app.worker
```

Open http://127.0.0.1:8012. Random local credentials are written once to `data/demo-credentials.json` with owner-only permissions. `sales` is assigned to Acme; `reviewer` to Acme and Nova; `admin` manages access without content/approval authority. Model keys belong only in the ignored `.env`/worker environment. No model request occurs during migration, seeding, or readiness checks.

This workstation's original development database uses `/private/tmp`, port `55439`, database `assuredesk`; its PostgreSQL cluster is `/private/tmp/assuredesk-pg`. It is temporary development storage. Use the persistent Compose volumes or a dedicated persistent database for deployment. Local HTTP is permitted only with `LOCAL_HTTP=1`; private hosting needs TLS and secure cookies.

## Workflow and architecture

```mermaid
flowchart LR
  Browser[Authenticated review UI] --> API[FastAPI: permissions and revisions]
  API --> DB[(PostgreSQL + pgvector)]
  API --> Objects[Immutable source and export files]
  Worker[One leased worker] --> DB
  Worker --> Embed[Local BGE embeddings]
  Worker --> Kimi[Kimi structured generation]
  API --> Parser[Confined parser subprocess]
```

```mermaid
flowchart TD
  Start[Reauthorize original principal] --> Search[Eligible hybrid retrieval]
  Search --> Assess[Assess every requested requirement]
  Assess -->|Complete proposal| Check[Separate support check]
  Assess -->|Missing evidence and budget remains| Search
  Check -->|Missing requirement and budget remains| Search
  Assess -->|Conflict, unclear scope, limit or no progress| Review[Explicit human review]
  Check -->|Supported| Review
  Review --> Revision[Revision-bound approval]
  Revision --> Export[Revalidate all rows and export]
  Export --> Download[Revalidate again at download]
```

Imports support one visible XLSX worksheet, up to 50 mapped rows, and separate response/explanation columns. Formulas, hidden content, macros, external relationships and unsupported objects fail closed. Review the extracted questions and destination coordinates before confirming. A clean export is built from the supported content; arbitrary Excel fidelity is not promised.

The reviewer sees requirement coverage, evidence excerpts, corrective searches and new evidence, immutable question/draft history, approval reasons, and a final export-coordinate preview. Answers are Yes, No, Partial, Not applicable, Unknown or Declined. Every row needs approval, including Unknown/Declined. Each material claim has an evidence mapping and an explicit revision-bound reviewer check. Editing question text, wording, evidence, source eligibility or permissions invalidates approval. Model support checks are aids, never disclosure authority.

Runs and their accumulated retrieval traces remain principal-bound, as required by the approved evaluation protocol. A reviewer can inspect an authorized draft's claim mappings/history, and start a separate run for their own access scope. Restricted reviewer search can inspect readable internal material; it never feeds internal-only content into customer generation.

Evidence formats are text PDFs, UTF-8 Markdown and scoped statement JSON (`{"statement":"..."}` plus curated upload metadata). Original objects are SHA-256 checked. Markdown locators retain headings. Suspected PDF tables/columns, scans, encrypted PDFs and unreliable text are rejected for curation rather than guessed. The parser has a read-only input, no credential environment, no network, CPU/file/time limits and memory protection. Linux requires Landlock ABI 3 or later for filesystem restrictions and uses libseccomp to deny sockets, process creation, signals to other processes and process inspection; macOS uses the OS sandbox and an RSS watchdog (not a Linux-style hard address-space limit).

Sources record parser/chunker versions, uploader/acquisition, index generation and content identity. Chunks have stable identities, exact spans, text hashes, embedding artifact fingerprints and preprocessing metadata. Pending generations are inactive until fully indexed; activation and explicit supersession commit together. `POST /v1/sources/{id}/reindex` builds a separate pending generation, then activate it with the prior source ID in `supersedes`. Identical embedding inputs with the same model/artifact revision reuse stored vectors.

Retrieval uses authorized BM25 and exact filtered pgvector, reciprocal-rank fusion, overlap deduplication, bounded source diversity, and at most six original excerpts/parents. Document titles participate in retrieval. Correction stops when neither useful supplied evidence nor supported requirement coverage improves. No web crawling, OCR, extra reranker, Jev, SSO or business-system connector is required.

## Limits and durability

Versioned non-secret limits live in `app/config.py`. The configured generator is `kimi-k3` through the official `https://api.moonshot.ai/v1` endpoint; embeddings remain local `BAAI/bge-small-en-v1.5`, 384 dimensions. Kimi generation uses strict structured JSON, local Pydantic validation, low reasoning effort, 1,200 completion tokens and no hidden retries. Parameters follow [Kimi's K3 guide](https://platform.kimi.ai/docs/guide/kimi-k3-quickstart) and [structured-output guidance](https://platform.kimi.ai/docs/guide/response_format). The generation input ceiling uses a conservative 6,000 UTF-8-byte bound including instructions/schema; local embeddings reject inputs above 450 tokens. Official K3 rates are $3/M input and $15/M output, plus up to $3/M for five-minute cache writes. The application conservatively reserves and estimates $6/M for every input token (input plus cache write) and $15/M output, without crediting cache-hit discounts. These are conservative application estimates, not invoice amounts. See [official model pricing](https://platform.kimi.ai/docs/pricing/chat).

Each run allows three retrieval rounds, five query embeddings, seven generation attempts including one shared repair, and 90 seconds active work excluding human review and provider admission waiting. Persisted reservations enforce $0.15/run, $5/workbook, $5/day, $15/evaluation batch and $30/campaign. Failures and uncertain calls remain charged conservatively. HTTP 429 errors are recorded. A daily/TPD limit stops the worker and evaluation batch; restart or resume only after the provider resets its allowance. Already recorded failures and uncertain charges remain counted. The single worker paces dispatches at least 20.1 seconds apart and respects a 65-second cooldown after a rate-limit response. Admission waiting is recorded separately from active work; reports include processing latency with that wait. Permissions, revisions, leases and spend are rechecked before dispatch. There is no hidden retry or automatic budget increase.

PostgreSQL leases use the database clock, fencing and per-run advisory locks. A persisted stage key binds run/node/checkpoint step; replay finds the existing stage output. Draft publication and stage completion commit together. A provider call interrupted before an artifact commits may incur another paid attempt, within the same caps; it is not presented as exactly-once billing. Checkpoints contain references only. Application approval rows remain authoritative.

## Verification

```sh
uv run ruff check .
uv run ruff format --check .
uv run mypy app/schema.py app/config.py --follow-imports=silent --ignore-missing-imports
uv run pytest -q
TEST_PARSER_SANDBOX=1 TEST_DATABASE_URL='YOUR_DISPOSABLE_TEST_DATABASE_URL' uv run pytest -q
PLAYWRIGHT_BROWSERS_PATH=data/browser-runtime uv run playwright install chromium
PLAYWRIGHT_BROWSERS_PATH=data/browser-runtime TEST_BROWSER=1 TEST_PARSER_SANDBOX=1 TEST_DATABASE_URL='YOUR_TEST_DATABASE_URL' uv run pytest -q --junitxml=output/tests.xml
```

The PostgreSQL test database must have `CREATE EXTENSION vector` applied, and its connection must be allowed to create disposable schemas. Tests never call the generation provider. Browser artifacts are in `output/playwright/`; [the inspectable answer screenshot](output/playwright/inspectable-answer.png) is generated from synthetic fixtures. The browser check exercises login, selection of permitted excerpts, claim review, approval, history, preview, export and source revocation. The [three-minute walkthrough](output/playwright/assuredesk-three-minute-demo.webm) additionally demonstrates import, initial incomplete retrieval, targeted correction with newly retrieved evidence, an explicit Unknown, approval, export and revocation. It is visibly labelled a scripted synthetic scenario: retrieval and policy operations are real, provider responses are deterministic fixtures. It is separate from the live model evaluation.

Re-record that walkthrough with `PLAYWRIGHT_BROWSERS_PATH=data/browser-runtime TEST_BROWSER=1 RECORD_DEMO=1 uv run pytest tests/test_browser.py::test_three_minute_walkthrough -q`. Process-death tests cover crashes before and after stage artifact commit; other tests cover lease expiry, checkpoint resume, cancellation, stale approvals and authorization boundaries.

`.github/workflows/verify.yml` runs lint/format/interface checks, deterministic tests, PostgreSQL migrations, secret scanning, a dependency/license inventory and a nonroot container check. No provider secret or paid evaluation is supplied to pull-request jobs.

## Evaluation

The corpus builder produces 48 synthetic Markdown/PDF/JSON sources and 120 grouped cases: 12/6/6 families and 60/30/30 development/validation/test questions. Cases include explicit caveats, conflicts, ambiguity, missing facts, role/customer counterfactuals, expiry and internal-only content. Gold requirements and source-version spans are separate from ingestion. They are not derived from the model's decomposition.

```sh
# Use a dedicated evaluation database/object directory, never the demonstration corpus.
uv run python -m app.evaluation build --root data/evaluation-v2
uv run python -m app.evaluation validate --root data/evaluation-v2
uv run python -m app.evaluation ingest --root data/evaluation-v2
uv run python -m app.evaluation run --root data/evaluation-v2 --split development --limit 5 --batch development-1 --campaign pilot-1 --interval 35
uv run python -m app.evaluation review-packet --root data/evaluation-v2
uv run python -m app.evaluation report --root data/evaluation-v2 --batch development-1
```

Before a locked run, review/correct the labels and run `freeze`. It binds source/case/configuration/model/prompt/lockfile hashes, stored vectors and permissions. An explicitly source-reviewed exploratory freeze is available with `--source-reviewed`; it does not assert independent human validation. Original judgments, adjudication, assertion/citation support and review time remain distinct. The report does not promote the generator's own support checks to ground truth.

Reports implement Recall@k, Precision@k, MRR and nDCG at 1/3/6/12/20, complete-bundle coverage at candidate and supplied-context stages, supported complete outcomes, selective precision, answer coverage, missed answerable cases, unsupported assertions, safe routing by disposition, citation integrity/entailment/coverage, paired correction recovery/regression, family-bootstrap intervals, approval mistakes, reviewer agreement, latency, tokens, attempts and spend. Every fraction retains its numerator/denominator. Empty denominators are null; missing runs and unscored judgments remain visible. A completed benchmark can fail its quality gate.

Ranking and bundle coverage use reference-ANSWERABLE cases, where an eligible retrieval target is defined. Failures within that population remain zero-scored. Other dispositions remain in routing, cost and failure counts. Precision@k includes unfilled result positions in its denominator. The reports retain both the population size and per-case values.

Measured development retrieval covers all 60 development questions without generation: dense supplied-context bundle coverage is 48/60 required claims (80%); hybrid is 52/60 (86.7%), evaluated on the 30 answerable development questions. Candidate coverage is 54/60 and 56/60 respectively. [Raw development retrieval](output/development-retrieval.json).

The completed 30-question validation comparison produced these source-reviewed results (15 answerable cases per variant):

| Variant | Complete supported answers | Selective precision | Known cost + uncertain reservation |
|---|---|---|---|
| dense | 3/15 | 3/3 | $0.0981 |
| hybrid | 6/15 | 6/8 | $0.0642 |
| corrective | 8/15 | 8/10 | $0.1593 |

Correction recovered 4 of the hybrid baseline’s 9 misses and regressed on 2 of its 6 successes. The paired change is +2/15, with a descriptive family-bootstrap interval of −26.7 to +53.3 percentage points: this does not establish a reliable improvement. Source review found omitted caveats, a qualification borrowed from the wrong document topic, and an unsupported exclusivity claim despite a positive model support check. Provider errors, malformed outputs and over-abstention remain counted. [Validation scores](output/validation-report.json) and [case report](output/evaluation/validation-report.md).

The final locked comparison completed all **30 questions × three variants**, including seven answerable questions:

| Variant | Complete supported | Final input bundle coverage | Provider-failed runs | Known cost + uncertain reservation |
|---|---|---|---|---|
| dense | 0/7 | 11/14 required claims | 13/30 | $0.1548 |
| hybrid | 1/7 | 13/14 required claims | 13/30 | $0.1540 |
| corrective | 0/7 | 13/14 required claims | 16/30 | $0.2104 |

The one substantive hybrid draft was supported; 1/1 selective precision does not offset its six missed answerable cases. Correction recovered 0/6 misses and regressed on 1/1 hybrid success. All 90 runs have source-grounded judgments, with no missing or unscored runs. The 90% gate failed. [Locked report](output/evaluation/locked-report.md) and [full automatic metrics](output/evaluation/locked-report.json).

There were 42 provider-failed runs, including rate limits retained from before credential replacement. The key changed after 46 recorded runs, and admission pacing changed from 12 to 20 seconds. Thus this is an operational comparison under provider disruption, not an isolated estimate of model quality or correction benefit. Even after access recovered, support checks rejected some answerable cases. No failed case was removed or replaced with a successful rerun.

The final locked comparison uses the same retrieval/generation configuration as validation with a Linux-only parser thread limit added after container acceptance exposed a NumPy subprocess problem. The earlier partial batch and exact measured code snapshots are retained. Subsequent changes only correct operations summaries and the ranking population; captured outputs, prompts, retrieval and gold labels are unchanged. [Revision record](output/evaluation/runtime-change.json). Human review duration and agreement are unmeasured (null/no pairs), not invented. No automatic answer was approved for a customer.

The complete campaign, including interrupted runs and diagnostics, recorded **$0.437236 known usage plus $1.123200 reserved for unknown usage** ($1.560436 accounted against limits). These are application estimates/reservations, not a provider invoice. [Ledger reconciliation](output/evaluation/campaign-costs.json).

[Evaluation artifacts](output/evaluation/evaluation-artifacts.zip) contain the synthetic documents, labels, bindings, freezes, batch plans, original runs and judgments. To reproduce scores without credentials or a database, extract that archive into a new directory and run `uv run python -m app.evaluation report --root PATH_TO_EXTRACTED_DIRECTORY --batch locked-frozen-v2`. The current scoring implementation is in [the release source snapshot](output/evaluation/release-implementation.zip); `final-implementation.zip` preserves the exact code used to capture the final live runs. Reproduction of live responses is nondeterministic and requires a separately authorized, budgeted batch; offline rescoring does not call the provider.

The semantic gate is at least 90% complete supported outcomes on the frozen locked answerable cases, with independent validation evidence. Safety gates require all supported workbook fixtures to pass, all unsupported fixtures to reject, and no observed unauthorized/stale exports in the mandatory suite. A small synthetic benchmark does not establish population reliability.

## Operations, deletion and recovery

The Operations view and `python -m app.operations status` show worker age, queue age, ingestion failures, provider failures, storage alerts and uncertain costs. Missing worker heartbeat (>150 seconds), queued work older than 120 seconds and storage above 80% raise alerts. Check configuration/worker health before resuming failures; never bypass a parser failure or raise budgets automatically. A model outage does not prevent manual review or valid downloads.

| Signal | Operator action |
|---|---|
| Missing heartbeat or ageing queue | Inspect the existing worker and database connection; stop a wedged worker before starting a replacement. Preserve its reservations. |
| Two authentication failures within 15 minutes | Check the worker's secret configuration and provider account; replace the credential and restart that worker. Never put the key in logs. |
| Provider rate limit | Pace new admissions; retain failed attempts and unknown charges. A daily/TPD response stops dispatches: wait for Kimi’s reset before restarting the worker or resuming the batch. Do not rotate credentials or increase caps. |
| Parser/resource failure | Review the supported file profile and confinement probe; curate or replace the input rather than disabling isolation. |
| Storage above 80% | Review retention and verified backups; use the application purge tools rather than removing referenced objects by hand. |
| Cap stop | Review recorded costs and the relevant reset period. Resume explicitly only within the existing limits. |
| Invalidated export | Reopen the questionnaire, inspect the changed inputs and obtain fresh approvals. Stale downloads remain blocked. |
| An unauthorized export in a fixture or reported incident | Stop release/export use, reproduce with a regression fixture and correct the policy boundary before resuming. |

Source deletion revokes eligibility, removes dependent workbook/draft/run/checkpoint content, purges unreferenced objects and retains a content-free tombstone. Because derived answers may contain source text, deleting a cited source also deletes affected questionnaires; deactivate instead when the intended action is only revocation. Retention defaults to 90 days. Preview before applying:

```sh
uv run python -m app.operations retention
uv run python -m app.operations retention --apply
```

Authenticated backups contain a PostgreSQL exported snapshot, immutable objects and a hash/consistency manifest. The key must be stored separately, with owner-only permissions. Restore refuses a nonempty database or object directory and fences uncertain jobs so they cannot silently repeat paid work.

```sh
uv run python -m app.operations keygen --key data/backup.key
uv run python -m app.operations backup --key data/backup.key --archive data/backups/assuredesk-snapshot.fernet
# DATABASE_URL and OBJECT_ROOT must point to a fresh recovery destination:
uv run python -m app.operations restore --key /secure/recovery.key --archive /secure/assuredesk-snapshot.fernet
# For daily operation, with an explicitly configured existing off-host directory:
uv run python -m app.operations daily --key /secure/recovery.key --off-host backup-host:/private/assuredesk/
```

Daily rotation retains seven recent snapshots and one prior-month snapshot. Schedule the existing `daily` command using the host’s scheduler after configuring its destination, for example this operator-installed cron entry (replace the paths/host):

```cron
15 2 * * * cd /srv/assuredesk && .venv/bin/python -m app.operations daily --key /secure/recovery.key --off-host backup-host:/private/assuredesk/ >> /var/log/assuredesk-backup.log 2>&1
```

Check a successful exit and the remote archive’s presence before treating a daily backup as delivered. No scheduler entry has been installed on this workstation. Off-host backup needs an actual operator-provided destination and a scheduled host job; neither is invented by this project. Backups age out under retention, so immediate erasure from every historical backup is not promised. Recovery targets are provisionally 24-hour data loss and four-hour restoration; the local drill is evidence of functionality, not an off-host service-level commitment.

## Containers

```sh
docker build -t assuredesk:acceptance .
docker compose up -d db
docker compose run --rm api alembic upgrade head
docker compose run --rm api python -m app.cli checkpoints
docker compose run --rm api python -m app.cli prepare-model
docker compose run --rm api python -m app.cli seed
docker compose run --rm api python -m app.cli check-parser
docker compose up -d api worker
```

The API has no model key; only the worker reads `.env`. Persistent volumes hold application objects/model files and PostgreSQL. The Linux parser uses unprivileged Landlock and retains Docker’s default seccomp/AppArmor policies, nonroot execution and capability dropping. Numerical libraries run with one thread inside the confined parser. Verify confinement on the intended host; do not assume a different container policy is compatible. Local ports bind only to loopback. A public deployment/TLS endpoint is outside this local pilot.

## Course adaptation ledger

Upstream provenance was rechecked on 4 October 2026:

| Repository | Upstream revision | License evidence / use |
|---|---|---|
| [Part 6](https://github.com/pdichone/fcc-production-rag-part-6) | `294c8ef829e07717ef91d1e119c3d9de7c6a7fb7` | README says MIT, but LICENSE endpoint returns 404. Conceptual adaptation only. |
| [Production course](https://github.com/pdichone/production-course-main-code) | `9933fe78aba0cba40812856d9baeb0640cad70ca` | LICENSE endpoint returns 404. Conceptual adaptation only. |

No tutorial source, prompts, credentials or assets were transplanted. `04_agentic_rag.py` informs the retrieve/assess/correct graph; `advanced_rag.py` informs hybrid fusion and bounded parents; `text_splitters.py` informs recursive splitting; `human_in_loop.py`/`checkpointing.py` inform persisted review interrupts; security/cost/testing examples inform policy checks, durable budgets and injected providers. The original planning [course reuse map](../AssureDesk%20planning/course-reuse-map.md) contains exact local-file fingerprints and the teaching shortcuts deliberately corrected here. Maintained LangChain/LangGraph libraries are used directly. `python -m app.cli inventory` records installed dependency versions/license metadata, including unreported licenses rather than inventing them.

## Acceptance ledger

| Area | Evidence / current status |
|---|---|
| Permissions, workbook, review, replay, parser | [Native suite](output/tests.xml): 99 passed, one optional recording test skipped; recording passed separately |
| Automatic scoring | Ranking, bundles, routing, citations, recovery/regression, costs and missing runs implemented; denominator regression tests passed |
| Corpus and frozen semantic comparison | 48 sources, 120 grouped cases; validation 90/90 and final locked 90/90 runs scored; semantic gate failed |
| UI | Real-browser approval/export/revocation passed; [three-minute demo](output/playwright/assuredesk-three-minute-demo.webm) passed in 182.89 seconds |
| Retention/deletion | Implemented; destructive behavior tested only on disposable fixtures |
| Recovery | [Fresh restore drill](output/restore-drill.json): five objects and five approvals verified; interrupted work fenced and unknown charge retained |
| Linux deployment / CI | 22 Linux integration tests passed; [Compose acceptance](output/container/acceptance.json) passed import, five reviews, export, revocation and stale-approval rejection; CI workflow implemented, no hosted CI run claimed |
| Operations | Review-routed provider failures, 15-minute authentication alert, cap stops, stale exports, worker/queue/storage checks verified in SQLite and PostgreSQL |
| Off-host scheduled backup | Requires an actual destination; local tools implemented |
| Independent human validation | Not established by assistant review; semantic release gate remains separate |

The [release manifest](output/release-manifest.json) records the image, migration, lockfile and verification artifacts. Detailed test outcomes are in [the fixture ledger](output/fixtures.jsonl). The application remains a local demonstration while its quality gate and external operational prerequisites are unmet.

The original UpgradeLens, FilingDelta and AssureDesk planning files are outside this implementation and were not modified.
