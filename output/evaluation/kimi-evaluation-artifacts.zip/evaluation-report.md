# AssureDesk evaluation

Batch: `kimi-locked-v1`; 90 recorded variant runs over 30 questions.

Status: scored. source-grounded review; no independent human validation claimed

Semantic release gate: **not passed** (complete-supported threshold 90%; independent validation required).
Frozen locked factual target met: True. Independent validation available: False.

| Variant | Supported complete | Selective precision | Missing / unscored | Known cost + uncertain reservation |
|---|---|---|---|---|
| dense | 6/13 | 6/8 | 0/0 | $0.429555 |
| hybrid | 10/13 | 10/10 | 0/0 | $0.475764 |
| corrective | 12/13 | 12/13 | 0/0 | $0.653589 |

Full retrieval, routing, citation, uncertainty, and cost counts: `report.json`.
Reference ANSWERABLE cases; failed retrievals remain zero-scored.
Unscored semantic outcomes are unresolved, never inferred from the model's own support check.

## Cases requiring review

- directory-provisioning-1 / dense: awaiting_review; not complete and supported
- directory-provisioning-1 / hybrid: awaiting_review; not complete and supported
- directory-provisioning-2 / dense: awaiting_review; not complete and supported
- directory-provisioning-2 / hybrid: awaiting_review; not complete and supported
- directory-provisioning-3 / dense: awaiting_review; not complete and supported
- directory-provisioning-3 / hybrid: provider_failed; not complete and supported
- directory-provisioning-3 / corrective: awaiting_review; not complete and supported
- directory-provisioning-4 / dense: needs_clarification; not complete and supported
- directory-provisioning-4 / hybrid: needs_clarification; not complete and supported
- directory-provisioning-4 / corrective: needs_clarification; not complete and supported
- artifact-signature-2 / dense: awaiting_review; not complete and supported
- artifact-signature-3 / dense: awaiting_review; not complete and supported
- artifact-signature-3 / hybrid: awaiting_review; not complete and supported
- artifact-signature-3 / corrective: awaiting_review; not complete and supported
- artifact-signature-4 / dense: needs_clarification; not complete and supported
- artifact-signature-4 / hybrid: needs_clarification; not complete and supported
- artifact-signature-4 / corrective: needs_clarification; not complete and supported
- browser-isolation-1 / dense: awaiting_review; not complete and supported
- browser-isolation-2 / dense: awaiting_review; not complete and supported
- browser-isolation-3 / dense: awaiting_review; not complete and supported
- browser-isolation-3 / hybrid: awaiting_review; not complete and supported
- browser-isolation-3 / corrective: awaiting_review; not complete and supported
- browser-isolation-4 / dense: needs_clarification; not complete and supported
- browser-isolation-4 / hybrid: needs_clarification; not complete and supported
- browser-isolation-4 / corrective: needs_clarification; not complete and supported
- build-credential-2 / dense: awaiting_review; not complete and supported
- build-credential-2 / hybrid: awaiting_review; not complete and supported
- build-credential-2 / corrective: awaiting_review; not complete and supported
- build-credential-3 / dense: awaiting_review; not complete and supported
- build-credential-3 / hybrid: awaiting_review; not complete and supported
- build-credential-3 / corrective: awaiting_review; not complete and supported
- build-credential-4 / dense: needs_clarification; not complete and supported
- build-credential-4 / hybrid: needs_clarification; not complete and supported
- build-credential-4 / corrective: needs_clarification; not complete and supported
- object-access-1 / dense: conflict; not complete and supported
- object-access-1 / hybrid: conflict; not complete and supported
- object-access-1 / corrective: conflict; not complete and supported
- object-access-2 / dense: conflict; not complete and supported
- object-access-2 / hybrid: conflict; not complete and supported
- object-access-2 / corrective: conflict; not complete and supported
- object-access-3 / dense: conflict; not complete and supported
- object-access-3 / hybrid: conflict; not complete and supported
- object-access-3 / corrective: conflict; not complete and supported
- object-access-4 / dense: conflict; not complete and supported
- object-access-4 / hybrid: needs_clarification; not complete and supported
- object-access-4 / corrective: needs_clarification; not complete and supported
- object-access-5 / dense: conflict; not complete and supported
- object-access-5 / hybrid: conflict; not complete and supported
- object-access-5 / corrective: conflict; not complete and supported
- regional-agreement-1 / dense: awaiting_review; not complete and supported
- regional-agreement-1 / hybrid: awaiting_review; not complete and supported
- regional-agreement-1 / corrective: awaiting_review; not complete and supported
- regional-agreement-2 / dense: awaiting_review; not complete and supported
- regional-agreement-3 / dense: awaiting_review; not complete and supported
- regional-agreement-3 / hybrid: awaiting_review; not complete and supported
- regional-agreement-3 / corrective: awaiting_review; not complete and supported
- regional-agreement-4 / dense: needs_clarification; not complete and supported
- regional-agreement-4 / hybrid: needs_clarification; not complete and supported
- regional-agreement-4 / corrective: needs_clarification; not complete and supported
- regional-agreement-5 / dense: awaiting_review; not complete and supported
- regional-agreement-5 / hybrid: awaiting_review; not complete and supported
- regional-agreement-5 / corrective: awaiting_review; not complete and supported
